library(vegan)

##读取数据
#读入物种数据，细菌门水平丰度表（OTU 水平数据量太大，后续的置换检验和变量选择过程很费时间，不方便做示例演示）
phylum <- read.delim('phylum_table.txt', row.names = 1, sep = '\t', stringsAsFactors = FALSE, check.names = FALSE)

#读取环境数据
env <- read.delim('env_table.txt', row.names = 1, sep = '\t', stringsAsFactors = FALSE, check.names = FALSE)

#############################
##RDA
#调用格式 1
#rda(Y, X, W)
#或者 2
#rda(Y~var1+var2+var3+factorA+var2*var3+Condition(var4))

#直接使用原始数据，不做转化。对于群落物种组成数据来讲（因为通常包含很多 0 值），不是很推荐
rda_result <- rda(phylum~., env, scale = FALSE)

##tb-RDA
#物种数据 Hellinger 预转化（处理包含很多 0 值的群落物种数据时，推荐使用）
phylum_hel <- decostand(phylum, method = 'hellinger')

#使用全部的环境数据
rda_tb <- rda(phylum_hel~., env, scale = FALSE)

#若只关注局部环境数据，除了在原始表格中修改变量个数外，还可直接在 rda() 中指定
#例如只考虑 pH、TC、TN、AP、AK 这 5 种环境变量
#rda_tb <- rda(phylum_hel~pH+TC+TN+AP+AK, env, scale = FALSE)

#默认情况下，rda(phylum_hel~., env)，不包含环境变量间的交互作用
#若想关注某两个环境变量间的交互作用，例如添加 TC 和 TN 的交互作用项
#rda_tb <- rda(phylum_hel~pH+TC+DOC+SOM+TN+NO3+NH4+AP+AK+TC*TN, env, scale = FALSE)

##偏 RDA
#例如控制土壤 pH 影响后（pH 作为协变量），观测其它环境因素的影响；物种数据 Hellinger 预转化
rda_part <- rda(phylum_hel~TC+DOC+SOM+TN+NO3+NH4+AP+AK+Condition(pH), data = env, scale = FALSE)

##db-RDA
#本篇不做介绍
#考虑到这种模式的 RDA 很重要，后面准备写一篇单独介绍它

##非线性 RDA *
#本文不做介绍
#可参见 “DanielBorcard, FranoisGillet, PierreLegendre, et al. 数量生态学:R语言的应用（赖江山 译）. 高等教育出版社, 2014.” 170-174 页内容

#############################
##RDA 结果解读，以下均以 tb-RDA 结果为例
#查看统计结果信息，以 I 型标尺为例
rda_tb.scaling1 <- summary(rda_tb, scaling = 1)
rda_tb.scaling1

#作图查看排序结果，三序图，包含 I 型标尺和 II 型标尺
#详情 ?plot.cca()，注意不是 ?plot
par(mfrow = c(1, 2))
plot(rda_tb, scaling = 1, main = 'I 型标尺', display = c('wa', 'sp', 'cn'))
rda_sp.scaling1 <- scores(rda_tb, choices = 1:2, scaling = 1, display = 'sp')
arrows(0, 0, rda_sp.scaling1[ ,1], rda_sp.scaling1[ ,2], length =  0, lty = 1, col = 'red')
plot(rda_tb, scaling = 2, main = 'II 型标尺', display = c('wa', 'sp', 'cn'))
rda_sp.scaling2 <- scores(rda_tb, choices = 1:2, scaling = 2, display = 'sp')
arrows(0, 0, rda_sp.scaling2[ ,1], rda_sp.scaling2[ ,2], length =  0, lty = 1, col = 'red')

#隐藏物种信息，以 I 型标尺为例展示双序图，并查看分别使用物种加权计算的样方坐标以及拟合的样方坐标的差异
par(mfrow = c(1, 2))
plot(rda_tb, scaling = 1, main = 'I 型标尺，加权', display = c('wa', 'cn'))
plot(rda_tb, scaling = 1, main = 'I 型标尺，拟合', display = c('lc', 'cn'))

##RDA 结果提取
#scores() 提取排序得分（坐标），以 I 型标尺为例，前四轴为例
#使用物种加权和计算的样方得分
rda_site.scaling1 <- scores(rda_tb, choices = 1:4, scaling = 1, display = 'wa')	
#物种变量（响应变量）得分
rda_sp.scaling1 <- scores(rda_tb, choices = 1:4, scaling = 1, display = 'sp')
#环境变量（解释变量）得分
rda_env.scaling1 <- scores(rda_tb, choices = 1:4, scaling = 1, display = 'bp')

#或者在 summary() 后提取，以 I 型标尺为例，前四轴为例
rda_tb.scaling1 <- summary(rda_tb, scaling = 1)
names(rda_tb.scaling1)
#使用物种加权和计算的样方得分
rda_site.scaling1 <- rda_tb.scaling1$site[ ,1:4]
#物种
rda_sp.scaling1 <- rda_tb.scaling1$species[ ,1:4]
#环境
rda_env.scaling1 <- rda_tb.scaling1$biplot[ ,1:4]

#若需要输出在本地
#样方
write.table(data.frame(rda_site.scaling1), 'rda_site.scaling1.txt', sep = '\t', col.names = NA, quote = FALSE)
#物种
write.table(data.frame(rda_sp.scaling1), 'rda_sp.scaling1.txt', sep = '\t', col.names = NA, quote = FALSE)
#环境
write.table(data.frame(rda_env.scaling1), 'rda_env.scaling1.txt', sep = '\t', col.names = NA, quote = FALSE)

#不建议直接在原始数据集中提取，因为这样提取的坐标数值未经标尺缩放处理，不利于反映生物学问题
#rda_tb$CCA$u[ ,1:4]
#rda_tb$CCA$v[ ,1:4]
#rda_tb$CCA$biplot[ ,1:4]

#coef() 提取典范系数
rda_coef <- coef(rda_tb)

#############################
##R2 校正
#RsquareAdj() 提取 R2，详情 ?RsquareAdj() 
r2 <- RsquareAdj(rda_tb)
rda_noadj <- r2$r.squared	#原始 R2
rda_adj <- r2$adj.r.squared	#校正后的 R2

#关于约束轴的解释量，应当在 R2 校正后手动计算

##置换检验，详情 ?anova.cca()，不要使用 ?anova
#所有约束轴的置换检验，基于 999 次置换检验
rda_tb_test <- anova(rda_tb, permutations = 999)
#或者使用
rda_tb_test <- anova.cca(rda_tb, step = 1000)

#各约束轴逐一检验，基于 999 次置换检验
rda_tb_test_axis <- anova(rda_tb, by = 'axis', permutations = 999)
#或者使用
rda_tb_test_axis <- anova.cca(rda_tb, by = 'axis', step = 1000)

#p 值校正（Bonferroni 为例）
rda_tb_test_axis$`Pr(>F)` <- p.adjust(rda_tb_test_axis$`Pr(>F)`, method = 'bonferroni')

##断棍模型和 Kaiser-Guttman 准则确定残差轴
#提取残差特征值
pca_eig <- rda_tb$CA$eig

#Kaiser-Guttman 准则
pca_eig[pca_eig > mean(pca_eig)]

#断棍模型
n <- length(pca_eig)
bsm <- data.frame(j=seq(1:n), p = 0)
bsm$p[1] <- 1/n
for (i in 2:n) bsm$p[i] <- bsm$p[i-1] + (1/(n + 1 - i))
bsm$p <- 100*bsm$p/n
bsm

# 绘制每轴的特征根和方差百分比 
par(mfrow = c(2, 1))
barplot(pca_eig, main = '特征根', col = 'bisque', las = 2)
abline(h = mean(pca_eig), col = 'red')
legend('topright', '平均特征根', lwd = 1, col = 2, bty = 'n')
barplot(t(cbind(100 * pca_eig/sum(pca_eig), bsm$p[n:1])), beside = TRUE, main = '% 变差', col = c('bisque', 2), las = 2)
legend('topright', c('% 特征根', '断棍模型'), pch = 15, col = c('bisque', 2), bty = 'n')

#############################
##变量选择
#计算方差膨胀因子
vif.cca(rda_tb)

#vegan 包 ordistep() 前向选择，基于 999 次置换检验，详情 ?ordistep()
rda_tb_forward_p <- ordistep(rda(phylum_hel~1, env, scale = FALSE), scope = formula(rda_tb), direction = 'forward', permutations = 999)

#vegan 包 ordiR2step() 前向选择，基于 999 次置换检验，详情 ?ordiR2step()
rda_tb_forward_r <- ordiR2step(rda(phylum_hel~1, env, scale = FALSE), scope = formula(rda_tb), R2scope = rda_adj, direction = 'forward', permutations = 999)

#以 rda_tb 和 rda_tb_forward_r 为例，简要绘制双序图比较变量选择前后结果
par(mfrow = c(1, 2))
plot(rda_tb, scaling = 1, main = '原始模型，I 型标尺', display = c('wa', 'cn'))
plot(rda_tb_forward_r, scaling = 1, main = '前向选择后，I 型标尺', display = c('wa', 'cn'))

#细节部分查看
summary(rda_tb_forward_r, scaling = 1)

#比较选择前后校正后 R2 的差异
RsquareAdj(rda_tb)$adj.r.squared
RsquareAdj(rda_tb_forward_r)$adj.r.squared

#packfor 包 forward.sel() 前向选择
library(packfor)
forward.sel(phylum_hel, env, adjR2thresh = rda_adj)

##提取或输出变量选择后的排序坐标
#以 ordiR2step() 结果为例，以 I 型标尺为例，前四轴为例
#提取方式可参考上文，这里通过 scores() 提取
#使用物种加权和计算的样方得分
rda_tb_forward_r_site.scaling1 <- scores(rda_tb_forward_r, choices = 1:4, scaling = 1, display = 'wa')
write.table(data.frame(rda_tb_forward_r_site.scaling1), 'rda_tb_forward_r_site.scaling1.txt', sep = '\t', col.names = NA, quote = FALSE)
#物种变量（响应变量）得分
rda_tb_forward_r_sp.scaling1 <- scores(rda_tb_forward_r, choices = 1:4, scaling = 1, display = 'sp')
write.table(data.frame(rda_tb_forward_r_sp.scaling1), 'rda_tb_forward_r_sp.scaling1.txt', sep = '\t', col.names = NA, quote = FALSE)
#环境变量（解释变量）得分
rda_tb_forward_r_env.scaling1 <- scores(rda_tb_forward_r, choices = 1:4, scaling = 1, display = 'bp')
write.table(data.frame(rda_tb_forward_r_env.scaling1), 'rda_tb_forward_r_env.scaling1.txt', sep = '\t', col.names = NA, quote = FALSE)

#############################
#变差分解部分，公众号中未展示，同样地，变差分解相关内容准备单独写一篇简述
#这里先大致展示一下好了

##变差分解 varpart()，以前向选择后的简约模型 rda_tb_forward_r 为例（包含 6 个环境解释变量）
#以两组环境变量为例，运行变差分解
rda_tb_forward_vp <- varpart(phylum_hel, env['pH'], env[c('DOC', 'SOM', 'AP', 'AK', 'NH4')])
rda_tb_forward_vp

plot(rda_tb_forward_vp, digits = 2, Xnames = c('pH', 'CNPK'), bg = c('blue', 'red'))

#查看前向选择中被剔除的环境变量“TC”，与这 6 个被保留的环境变量之间解释变差的“共享程度”
rda_tb_forward_vp <- varpart(phylum_hel, env['TC'], env[c('pH', 'DOC', 'SOM', 'AP', 'AK', 'NH4')])
plot(rda_tb_forward_vp, digits = 2, Xnames = c('TC', 'forward_env'), bg = c('blue', 'red'))

#解释变差的置换检验，以 pH 所能解释的全部变差为例；999 次置换
anova(rda(phylum_hel, env['pH']), permutations = 999)
#若考虑 pH 单独解释的变差部分，需将其它变量作为协变量；999 次置换
anova(rda(phylum_hel, env['pH'], env[c('DOC', 'SOM', 'AP', 'AK', 'NH4')]), permutations = 999)

#############################
##plot() 作图示例，详情 ?plot.cca
#以前向选择后的简约模型 rda_tb_forward_r 为例，展示前两轴，I 型标尺，双序图，默认使用物种加权和计算的样方坐标
#注意 RDA 轴的解释率，需要手动结合校正后的 R2 计算下
png('rda_test1.png', width = 600, height = 600, res = 100, units = 'px')
plot(rda_tb_forward_r, display = c('wa', 'cn'), choices = 1:2, scaling = 1, type = 'n', main = 'RDA双序图，I型标尺', xlab = 'RDA1 (42.91%)', ylab = 'RDA2 (9.80%)')
text(rda_tb_forward_r, display = 'cn', choices = 1:2, scaling = 1, col = 'blue', cex = 0.8)
points(rda_tb_forward_r, display = 'wa', choices = 1:2, scaling = 1, pch = 19, col = c(rep('red', 9), rep('orange', 9), rep('green3', 9)), cex = 1)
dev.off()

##ggplot2 作图
#以前向选择后的简约模型 rda_tb_forward_r 为例，展示前两轴，I 型标尺，双序图，默认使用物种加权和计算的样方坐标

#提取样方和环境因子排序坐标，前两轴，I 型标尺
rda_tb_forward_r.scaling1 <- summary(rda_tb_forward_r, scaling = 1)
rda_tb_forward_r.site <- data.frame(rda_tb_forward_r.scaling1$sites)[1:2]
rda_tb_forward_r.env <- data.frame(rda_tb_forward_r.scaling1$biplot)[1:2]

#读取样本分组数据（附件“group.txt”）
group <- read.delim('group.txt', sep = '\t', stringsAsFactors = FALSE, check.names = FALSE)

#合并样本分组信息，构建 ggplot2 作图数据集
rda_tb_forward_r.site$sample <- rownames(rda_tb_forward_r.site)
rda_tb_forward_r.site <- merge(rda_tb_forward_r.site, group, by = 'sample')

rda_tb_forward_r.env$sample <- rownames(rda_tb_forward_r.env)

#ggplot2 作图
library(ggplot2)

p <- ggplot(rda_tb_forward_r.site, aes(RDA1, RDA2)) +
geom_point(aes(color = group)) +
scale_color_manual(values = c('red', 'orange', 'green3')) +
theme(panel.grid = element_blank(), panel.background = element_rect(color = 'black', fill = 'transparent'), plot.title = element_text(hjust = 0.5), legend.key = element_rect(fill = 'transparent')) + 
labs(x = 'RDA1 (42.91%)', y = 'RDA2 (9.80%)', title = 'RDA双序图，I型标尺', color = '') +
geom_vline(xintercept = 0, color = 'gray', size = 0.5) + 
geom_hline(yintercept = 0, color = 'gray', size = 0.5) +
geom_segment(data = rda_tb_forward_r.env, aes(x = 0, y = 0, xend = RDA1,yend = RDA2), arrow = arrow(length = unit(0.1, 'cm')), size = 0.3, color = 'blue') +
geom_text(data = rda_tb_forward_r.env, aes(RDA1 * 1.1, RDA2 * 1.1, label = sample), color = 'blue', size = 3)

p

#ggsave('rda_test2.pdf', p, width = 5, height = 4)
ggsave('rda_test2.png', p, width = 5, height = 4)
