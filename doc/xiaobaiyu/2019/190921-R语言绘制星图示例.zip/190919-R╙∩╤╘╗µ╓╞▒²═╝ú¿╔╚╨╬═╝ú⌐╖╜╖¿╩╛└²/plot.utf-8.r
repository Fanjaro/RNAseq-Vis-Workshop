############################################
#读取数据
phylum <- read.delim('phylum.txt', sep = '\t', stringsAsFactors = FALSE, check.names = FALSE)

#pie()，可使用 ?pie 查看该命令详情
pie(phylum$a1, col = c('#8DD3C7', '#FFFFB3', '#BEBADA', '#FB8072', '#80B1D3', '#FDB462'), 
	labels = phylum$phylum, font = 3, main = 'Sample: a1\nPhylum level')

#pie3D()，可使用 ?pie3D 查看该命令详情
library(plotrix)

pie3D(phylum$a1, col = c('#8DD3C7', '#FFFFB3', '#BEBADA', '#FB8072', '#80B1D3', '#FDB462'), 
	explode = 0.05, height = 0.1, radius = 0.85, labels = phylum$phylum, labelcex = 1, main = 'Sample: a1\nPhylum level')

#fan.plot()，可使用 ?fan.plot 查看该命令详情
library(plotrix)

fan.plot(phylum$a1, col = c('#8DD3C7', '#FFFFB3', '#BEBADA', '#FB8072', '#80B1D3', '#FDB462'), 
	labels = phylum$phylum, main = 'Sample: a1\nPhylum level')

#ggplot2
library(ggplot2)

p <- ggplot(phylum, aes(x = '', y = a1, fill = phylum)) + 
geom_bar(stat = 'identity', width = 1) +
coord_polar(theta = 'y') +
scale_fill_manual(values = rev(c('#8DD3C7', '#FFFFB3', '#BEBADA', '#FB8072', '#80B1D3', '#FDB462'))) +
theme(panel.grid = element_blank(), panel.background = element_blank(), axis.text.x = element_blank(), plot.title = element_text(hjust = 0.5)) +
theme(legend.text = element_text(face = 'italic'), legend.title = element_blank()) +
labs(x = '', y = '', title = 'Sample: a1', fill = 'Phylum')

p

#ggsave('ggplot2_plot.pdf', p, width = 5, height = 5)
ggsave('ggplot2_plot.png', p, width = 5, height = 5)

p <- ggplot(phylum, aes(x = '', y = a1, fill = phylum)) + 
geom_bar(stat = 'identity', width = 0.3) +
coord_polar(theta = 'y') +
scale_fill_manual(values = rev(c('#8DD3C7', '#FFFFB3', '#BEBADA', '#FB8072', '#80B1D3', '#FDB462'))) +
theme(panel.grid = element_blank(), panel.background = element_blank(), axis.text.x = element_blank(), plot.title = element_text(hjust = 0.5)) +
theme(legend.text = element_text(face = 'italic'), legend.title = element_blank()) +
labs(x = '', y = '', title = 'Sample: a1', fill = 'Phylum')

p
