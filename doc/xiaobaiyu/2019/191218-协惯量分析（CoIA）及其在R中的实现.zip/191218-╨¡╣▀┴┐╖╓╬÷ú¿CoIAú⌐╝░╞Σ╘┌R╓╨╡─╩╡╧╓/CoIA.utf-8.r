#bioconductor 安装 made4 包
BiocManager::install('made4')

#加载 made4 包，made4 以 ade4 为基础（调用 ade4 的函数），所以它也会自动加载 ade4 包
library(made4)

##数据集
#详情 http://www.bioinf.ucd.ie/people/aedin/R/pages/made4/html/NCI60.html
data(NCI60)
names(NCI60)

head(NCI60$Ross[1:6])	#spotted cDNA 微阵列
head(NCI60$Affy[1:6])	#Affymetrix 微阵列
head(NCI60$classes)	#细胞系的癌细胞类型

##ade4 执行 CoIA
#这里对于两组基因表达谱，可执行 PCA-PCA 融合的 CoIA

#首先执行数据集1（spotted cDNA 微阵列矩阵）的 PCA，详情 ?dudi.pca
dudi1 <- dudi.pca(NCI60$Ross, scale = FALSE, scan = FALSE, nf = 4)

#其次执行数据集2（Affymetrix 微阵列矩阵）的 PCA
dudi2 <- dudi.pca(NCI60$Affy, scale = FALSE, scan = FALSE, nf = 4)

#查看两步 PCA 的总方差由各轴的承载比，评估前几轴的代表性
summary(dudi1)
summary(dudi2)

#查看两步排序的行权重是否一致，为 TRUE 时才可用于融合
all.equal(dudi1$lw, dudi2$lw)

#PCA-PCA 融合的 CoIA，详情 ?coinertia
coin1 <- coinertia(dudi1, dudi2, scan = FALSE, nf = 2)
coin1

summary(coin1)

#置换检验确定 CoIA 轴的显著性
rand_test <- randtest(coin1, nrepet = 999)
rand_test

plot(rand_test)

##提取主要结果，以融合后的结果为例
summary_coin1 <- summary(coin1)
names(coin1)
names(summary_coin1)

#各轴特征值
coin1$eig
#各轴特征值贡献度
coin1$eig / sum(coin1$eig)
#dudi1 对象坐标
coin1$co
#dudi2 对象坐标
coin1$li

#CoIA 分析协惯量矩阵特征根的分解情况
summary_coin1$EigDec

##排序图，ade4 打包好的作图样式
plot(coin1)
