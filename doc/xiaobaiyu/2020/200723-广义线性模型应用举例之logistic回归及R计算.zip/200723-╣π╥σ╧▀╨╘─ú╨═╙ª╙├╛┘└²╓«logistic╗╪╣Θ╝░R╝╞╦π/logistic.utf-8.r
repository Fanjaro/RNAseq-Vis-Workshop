#威斯康星州乳腺癌数据集
breast <- read.csv('http://archive.ics.uci.edu/ml/machine-learning-databases/breast-cancer-wisconsin/breast-cancer-wisconsin.data',na.strings = '?', header = FALSE)
names(breast) <- c('ID', 'clumpThickness', 'sizeUniformity', 'shapeUniformity', 'maginalAdhesion',
    'singleEpithelialCellSize', 'bareNuclei', 'blandChromatin', 'normalNucleoli', 'mitosis', 'class')

str(breast)

#网盘中也备份了一份数据
#breast <- read.csv('breast.csv')

#预先将 class 列转换为类别或因子变量，或者重新定义为 0-1 类型
#为了方便下文部分作图过程，以重新定义的新列（0，良性；1，恶性）数据进行后续分析
breast[which(breast$class == 2),'class2'] <- 0
breast[which(breast$class == 4),'class2'] <- 1

############细胞特征得分与肿瘤状态的单变量logistic回归

#首先展示肿瘤厚度得分与肿瘤状态的一元 logistic 回归示例
#通过广义线性回归函数 glm() 执行 logistic 回归，详情 ?glm
#通过 family 参数指定了二项回归，即二分响应的 logistic 回归
fit_logistic1 <- glm(class2~clumpThickness, data = breast, family = binomial())

summary.glm(fit_logistic1)  #展示拟合回归的简单统计

logistic_coef <- coef(fit_logistic1)  #提取回归系数
exp(logistic_coef)  #指数化回归系数

#模型预测
#predict() 默认输出肿瘤为恶性的对数概率
#指定参数 type='response' 即可得到预测肿瘤为恶性的概率
prob <- predict(fit_logistic1, breast, type = 'response')
head(prob)

plot(breast$clumpThickness, prob, pch = 20, col = 'red', 
    xlab = 'clumpThickness（肿瘤厚度得分）', 
    ylab = 'probability（肿瘤为恶性的可能性）')

#一元 logistic 回归的散点图
library(arm)

plot(jitter(class2, factor = 0)~clumpThickness, data = breast, 
    type = 'n', xlab = 'clumpThickness（肿瘤厚度得分）', 
    ylab = 'probability（肿瘤为恶性的可能性）')
points(jitter(class2, factor = 0.3)~clumpThickness, data = breast, 
    col = '#00000022', pch = 20)
points(breast$clumpThickness, prob, pch = 20, col = 'red')
curve(invlogit(logistic_coef[1] + logistic_coef[2] * x), add = TRUE, col = 'red')

#模型预测
#predict() 默认输出肿瘤为恶性的对数概率
#指定参数 type='response' 即可得到预测肿瘤为恶性的概率
prob <- predict(fit_logistic1, breast, type = 'response')

#将概率大于 0.5 判定为恶性肿瘤，不大于 0.5 为良性
pred <- ifelse(prob > 0.5, 1, 0)
perf <- table(breast$class2, pred, dnn = c('Actual', 'Predicted'))
perf  #Actual是真实值，Predicted是预测值，0是良性肿瘤，1是恶性肿瘤

#通过单变量 clumpThickness（肿瘤厚度得分）的预测准确性
(perf[1,1]+perf[2,2]) / sum(perf)

############细胞特征得分与肿瘤状态的多变量logistic回归

#首先不妨使用全部细胞特征变量拟合与肿瘤状态的多元 logistic 回归
#通过广义线性回归函数 glm() 执行 logistic 回归，详情 ?glm
#通过 family 参数指定了二项回归，即二分响应的 logistic 回归，其余参数暂且使用默认值
fit_logistic_multi <- glm(class2~clumpThickness+sizeUniformity+shapeUniformity+maginalAdhesion+singleEpithelialCellSize+bareNuclei+blandChromatin+normalNucleoli+mitosis, 
    data = breast, family = binomial())

summary.glm(fit_logistic_multi)  #展示拟合回归的简单统计

#上式可以简化为下式，其中“.”代表了数据集中除 class2 列外的其它所有列
#使用该式时，需保证除 class2 列外，其与所有列都作为自变量看待
#因此需要将数据集中的无效列，如代表样本编号的 ID 列和原始肿瘤状态的 class 列剔除
breast <- breast[ ,-which(colnames(breast) %in% c('ID', 'class'))]
fit_logistic_multi <- glm(class2~., data = breast, family = binomial())

summary.glm(fit_logistic_multi)  #展示拟合回归的简单统计

logistic_coef <- coef(fit_logistic_multi)  #提取回归系数
exp(logistic_coef)  #指数化回归系数

#只使用观察到的显著和接近显著的 5 种细胞特征拟合与肿瘤状态的 logistic 回归
#这里除了更改协变量外，其余参数使用默认值，和先前一致
fit_logistic_multi2 <- glm(class2~clumpThickness+maginalAdhesion+bareNuclei+blandChromatin+normalNucleoli, 
    data = breast, family = binomial())

summary.glm(fit_logistic_multi2)  #展示拟合回归的简单统计

#anova() 检验两个嵌套模型的拟合优度
#卡方检验可用于比较广义线性模型
anova(fit_logistic_multi, fit_logistic_multi2, test = 'Chisq')

#AIC（Akaike Information Criterion，赤池信息准则）评估两个回归复杂性与拟合优度的关系
#AIC 值较小的回归优先选择，表明较少的预测变量已经获得了足够的拟合度
AIC(fit_logistic_multi, fit_logistic_multi2)

#后向逐步回归自动选择变量
fit_logistic_reduced <- step(fit_logistic_multi, direction = 'backward')
fit_logistic_reduced

#模型预测
#predict() 默认输出肿瘤为恶性的对数概率
#指定参数 type='response' 即可得到预测肿瘤为恶性的概率
prob_multi <- predict(fit_logistic_multi, breast, type = 'response')
prob_multi2 <- predict(fit_logistic_multi2, breast, type = 'response')

#将概率大于 0.5 判定为恶性肿瘤，不大于 0.5 为良性
pred_mult <- ifelse(prob_multi > 0.5, 1, 0)
perf_mult <- table(breast$class2, pred_mult, dnn = c('Actual', 'Predicted'))
perf_mult  #全部的 9 个细胞特征得分对肿瘤恶性状态的预测性能
(perf_mult[1,1]+perf_mult[2,2]) / sum(perf_mult)

pred_mult2 <- ifelse(prob_multi2 > 0.5, 1, 0)
perf_mult2 <- table(breast$class2, pred_mult2, dnn = c('Actual', 'Predicted'))
perf_mult2  #去除 4 个不显著细胞特征得分后对肿瘤恶性状态的预测性能
(perf_mult2[1,1]+perf_mult2[2,2]) / sum(perf_mult2)

############偏大离差及类二项回归

#检测偏大离差的一种方法是比较二项分布模型的残差偏差与残差自由度
#偏离 1 程度较大提示存在偏大离差
deviance(fit_logistic_multi2)/df.residual(fit_logistic_multi2)

#检验，零假设不存在偏大离差
#p 值显著则拒绝零假提示存在偏大离差
fit <- glm(class2~clumpThickness+maginalAdhesion+bareNuclei+blandChromatin+normalNucleoli, 
    data = breast, family = binomial())
fit.od <- glm(class2~clumpThickness+maginalAdhesion+bareNuclei+blandChromatin+normalNucleoli, 
    data = breast, family = quasibinomial())
pchisq(summary(fit.od)$dispersion * fit$df.residual, fit$df.residual, lower = FALSE)

#考虑了偏大离差问题的logistic回归
#通过广义线性回归函数 glm() 执行时， family 参数指定 quasibinomial，详情 ?glm
fit_quasibinomial <- glm(class2~clumpThickness+maginalAdhesion+bareNuclei+blandChromatin+normalNucleoli, 
    data = breast, family = quasibinomial())

summary.glm(fit_quasibinomial)  #展示拟合回归的简单统计

#先前的多变量 logistic 回归
summary.glm(fit_logistic_multi2)
