#读取数据
dat <- read.delim('journal.pbio.2003862.s002.txt')

#其中 Compartment 列记录了样本取样的微尺度区域，包含 4 个类别变量
#包括土壤（Bulk Soil）、根际（Rhizosphere）、根表（Rhizoplane）和根内（Endosphere）
levels(dat$Compartment)

#为了探索微生物由土壤到根系的富集模式，需要用离散数值代指有序的土壤-根系区域空间微尺度
#指定 Bulk Soil=0、Rhizosphere=1、Rhizoplane=2、Endosphere=3
dat$compartment_num <- ifelse(dat$Compartment == 'Bulk Soil', 0, 
    ifelse(dat$Compartment == 'Rhizosphere', 1,
       ifelse(dat$Compartment == 'Rhizoplane', 2,
            ifelse(dat$Compartment == 'Endosphere', 3, NA))))

#########################
#不妨首先以酸杆菌门（Acidobacteria）为例，展示一些细节
dat_acidobacteria <- subset(dat, Phylum2 == 'Acidobacteria')

#观察 Acidobacteria 相对丰度的分布特征
library(ggplot2)

ggplot(dat_acidobacteria, aes(x = RA, stat(density))) +
geom_histogram(aes(fill = Compartment, color = Compartment), bins = 30, alpha = 0.2) +
geom_line(aes(color = Compartment), stat = 'density', size = 1.5) +
xlim(0, 1)

#探究 Acidobacteria 相对丰度是否由土壤到根系发生富集或降低
#参数详情 ?betareg，不过这里各参数使用默认值（因为看到作者原文中的分析代码，也都是用的默认参数）
library(betareg)

fit_beta <- betareg(RA~compartment_num, data = dat_acidobacteria)
summary(fit_beta)  #展示拟合回归的简单统计

#通过 names() 可查看统计结果中包含的内容项，便于从中选择关注的信息
fit_summary <- summary(fit_beta)
names(fit_summary)

#然后结合 $ 从中提取需要的信息，例如
fit_summary$coefficients$mean[1,1]  #截距项
fit_summary$coefficients$mean[1,4]  #截距项的显著性
fit_summary$coefficients$mean[2,1]  #微尺度区域的回归系数
fit_summary$coefficients$mean[2,4]  #微尺度区域的回归系数的显著性
fit_summary$coefficients$precision[1,1]  #phi 的参数估计值
fit_summary$coefficients$precision[1,4]  #phi 的显著性

#可通过 predict() 根据已知回归模型预测 Acidobacteria 在各土壤-根系微尺度区域取样样本中的期望丰度
acidobacteria_pred <- predict(fit_beta, dat_acidobacteria, type = 'response')
head(acidobacteria_pred)

#作图查看 Acidobacteria 相对丰度由土壤到根系的降低趋势
library(ggplot2)

dat_acidobacteria$pred <- acidobacteria_pred
pred <- dat_acidobacteria[!duplicated(dat_acidobacteria$compartment_num), ]

ggplot(data = dat_acidobacteria) +
geom_boxplot(aes(compartment_num, RA, color = Compartment), alpha = 0.5, width = 0.2, outlier.alpha = 0) +
geom_jitter(aes(compartment_num, RA, color = Compartment), alpha = 0.5, width = 0.2, size = 0.7) +
geom_line(data = pred, aes(compartment_num, pred)) +
scale_color_manual(values = c('#4C4C4C', '#688A21', '#3F68E1', '#B02121'), 
    limits = c('Bulk Soil', 'Rhizosphere', 'Rhizoplane', 'Endosphere')) +
scale_x_continuous(breaks = c(0, 1, 2, 3), labels = c('0\nBulk Soil', '1\nRhizosphere', '2\nRhizoplane', '3\nEndosphere')) +
theme(panel.grid = element_blank(), panel.background = element_blank(), 
    axis.line = element_line(color = 'black'), legend.position = 'none') +
labs(x = '', y = 'RA (relative abundance)')

#########################
#自定义一个函数，用于执行 beta 回归，并从中提取重要的回归参数值
beta_fit <- function(data) {
    fit_beta <- betareg(RA~compartment_num, data)  #beta 回归执行
    
    coefficient <- fit_summary$coefficients  #截距和回归系数的各参数估计
    phi <- fit_summary$coefficients$precision  #phi 的各参数估计
    dat <- data.frame(rbind(coefficient, phi), check.names = FALSE)  #合并输出
    
    dat$label <- unique(as.character(data$Phylum2))
    dat
}

#批处理运行所有细菌门的 beta 回归
dat <- subset(dat, ! Phylum2 %in% c('GN04', 'WS2'))  #这两个微生物门有问题，不知为啥会报错，就直接踢了

result <- NULL
for (phylum in unique(dat$Phylum2)) {
    dat_phylum <- subset(dat, Phylum2 == phylum)
    phylum_beta <- summary(betareg(RA~compartment_num, dat_phylum))  #beta 回归执行
    coefficient <- phylum_beta$coefficients$mean  #截距和回归系数的各参数估计
    phi <- phylum_beta$coefficients$precision  #phi 的各参数估计
    
    result_phylum <- data.frame(rbind(coefficient, phi), check.names = FALSE)  #合并输出
    term <- rownames(result_phylum)
    result_phylum <- cbind(term, result_phylum)
    result_phylum$phylum <- phylum
    result <- rbind(result, result_phylum)
}

head(result)

#输出结果表格，可以比较和原文附录中提供的回归系数、显著性等统计结果，是完全一致的
write.table(result, 'compartment_beta.txt', sep = '\t', quote = FALSE, row.names = FALSE)

#仿照原文，使用棒棒糖图对根系相关细菌门的可视化
#显著富集或降低的用实心点展示，不显著的用空心点展示
select <- subset(result, term=='compartment_num')
select[which(select$'Pr(>|z|)' < 0.05),'sig'] <- '1'
select[which(select$'Pr(>|z|)' >= 0.05),'sig'] <- '0'

select <- select[order(select$Estimate), ]
select$phylum <- factor(select$phylum, levels = select$phylum)

ggplot(select, aes(phylum, Estimate)) +
geom_segment(aes(x = phylum, xend = phylum, y = 0, yend = Estimate)) +
geom_point(aes(shape = sig)) +
scale_shape_manual(values = c(1, 16)) +
theme_bw() +
theme(axis.text.x = element_text(angle = 45, hjust = 1))


