##测试文件说明
#otu_table.txt，OTU 丰度表，绝对丰度相对丰度都可以
#otu_table_tax_assignments.txt，OTU 注释文件，我用 silva 注释的（大家随意）
#group.txt，样本分组文件
#1-summarize_trans.py、2-lefse_trans.py，两个自备的脚本

##首先借助 qiime 工具，从 OTU 水平的丰度表获得“界门纲目科属”水平的微生物类群丰度表
#可使用 conda 安装 qiime 环境
#conda create -n qiime1 qiime

#激活 qiime 环境
source activate qiime1

#在 otu_table.tsv 开头添加一行“# Constructed from biom file”，以便将 otu_table.tsv 转为 qiime 可识别样式
cp otu_table.txt otu_table.tsv
sed -i '1i\# Constructed from biom file' otu_table.tsv

#otu_table.tsv 转换为 biom 格式
biom convert -i otu_table.tsv -o otu_table.biom --table-type="OTU table" --to-json

#添加 otu 注释信息至 biom 格式的 otu 表（otu_table.biom ）的最后一列，并将列名称命名为 taxonomy
biom add-metadata -i otu_table.biom --observation-metadata-fp otu_table_tax_assignments.txt -o otu_table.silva.biom --sc-separated taxonomy --observation-header OTUID,taxonomy 

#使用 qiime 实现对 otu 表的“界门纲目科属”统计
summarize_taxa.py -i otu_table.silva.biom -o taxonomy

#退出 qiime 环境
source deactivate qiime1

##接下来，使用自写脚本合并“界门纲目科属”统计的类群，并转换为 LEfSe 的输入格式
#合并“界门纲目科属”统计的类群，并排序，结束后 taxonomy 路径下获得“otu_table.silva_all.txt”
python2 1-summarize_trans.py -i taxonomy --prefix otu_table.silva

#过滤去除注释为“Other”的微生物类群
grep -v 'Other' taxonomy/otu_table.silva_all.txt > otu_table.silva_filt.txt

#将“otu_table.silva_filt.txt”转化为 LEfSe 的输入格式，并合并分组（group.txt 文件）
python2 2-lefse_trans.py otu_table.silva_filt.txt group.txt otu_table_for_lefse.txt

#最后的“otu_table_for_lefse.txt”就是了
#该脚本只支持添加 class 组，若存在 sub_class 组可后续手动添加即可
#就是过程有点繁琐......主要懒得自写代码统计“界门纲目科属”，就用 qiime 来做，就烦 qiime 必须识别 biom 文件，还得来回转格式
#后续哪天闲了重新整个不借助 qiime 的
