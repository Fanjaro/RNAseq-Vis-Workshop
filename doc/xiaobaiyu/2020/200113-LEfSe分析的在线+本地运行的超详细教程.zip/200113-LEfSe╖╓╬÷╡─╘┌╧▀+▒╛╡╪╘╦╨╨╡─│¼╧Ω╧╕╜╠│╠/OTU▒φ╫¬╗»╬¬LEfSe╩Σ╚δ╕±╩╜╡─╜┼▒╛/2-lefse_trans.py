#!/usr/bin/env python
# -*- coding: utf-8 -*- #

import sys

group = {}
with open(sys.argv[2]) as group_fp:
    for line in group_fp:
        line = line.strip().split('\t')
        group[line[0]] = line[1]

groups = []
with open(sys.argv[1]) as in_fp, open(sys.argv[3], 'w') as out_fp:
    head = in_fp.next()
    samples = head.strip().split('\t')[1:]
    remain_samples = []
    ind_list = []
    for ind, sample in enumerate(samples):
        try:
            groups.append(group[sample])
            remain_samples.append(sample)
            ind_list.append(ind)
        except KeyError, ex:
            print('%s 样本不在分组文件中' % ex)
            continue
    samples = remain_samples
    out_fp.write('class\t%s\n' % '\t'.join(groups))
    out_fp.write('Taxon\t%s\n' % '\t'.join(samples))
    for line in in_fp:
        tabs = line.strip().split('\t')
        tmp = []
        for ind_t, sample_t in enumerate(tabs):
            xiabiao = ind_t - 1
            if xiabiao in ind_list:
                tmp.append(sample_t)
        if tabs[0].endswith('Other'):
            continue
        if tabs[0].endswith('norank'):
            continue
        if tabs[0].endswith('unclassfied'):
            continue
        tabs[0] = tabs[0].replace(';', '|')
        out_fp.write(tabs[0] + '\t')
        out_fp.write('\t'.join(tmp) + '\n')

group_fp.close()
in_fp.close()
out_fp.close()
