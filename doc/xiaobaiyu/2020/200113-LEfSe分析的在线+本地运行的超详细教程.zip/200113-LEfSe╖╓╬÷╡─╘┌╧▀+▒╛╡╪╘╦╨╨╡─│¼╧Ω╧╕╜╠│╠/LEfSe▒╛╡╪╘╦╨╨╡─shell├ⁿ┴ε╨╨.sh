#conda 安装 LEfSe
conda install -c biobakery lefse
#或者
conda install -c bioconda lefse

##对应于上述 A-F 6 个模块，本地版的命令行操作示例如下

#A，设置 LEfSe 的数据格式，详情 format_input.py -h
#-c，指定 class 的行（必须指定）；-s，指定 sub_class 的行（可缺省）；-u，指定 subject_id 的行（可缺省）；-o，设置归一化值，默认 -1 即不执行标准化
#注：版本问题，有时 format_input.py 命令找不到，可能为 lefse-format_input.py 
format_input.py lefse_test.txt A_lefse_test.in -c 1 -s 2 -u 3 -o 1000000

#B，LEfSe 分析，详情 run_lefse.py -h
#-l 2.0，设定 LDA 得分的对数值的最低阈值为 2
run_lefse.py A_lefse_test.in B_lefse_test.res -l 2.0

#备注：对于 B 的输出，我们可以选择从中删一些不必要（不显著）的数据，以增强 C、D、E 作图时的美感

#C，绘制 LEfSe 得分值，详情 plot_res.py -h
#注：版本问题，有时 plot_res.py 命令找不到，可能为 lefse-plot_res.py
plot_res.py B_lefse_test.res C_lefse_test.lda.pdf --format pdf --dpi 150 --width 16

#D，绘制进化分支图，详情 plot_cladogram.py -h
#注：版本问题，有时 plot_cladogram.py 命令找不到，可能为 lefse-plot_cladogram.py
plot_cladogram.py B_lefse_test.res D_lefse_test.cladogram.pdf --format pdf --dpi 150

#E，单张图的展示略，直接使用 F 绘制所有的图

#F，绘制差异特征，详情 plot_features.py -h
#注：版本问题，有时 plot_features.py 命令找不到，可能为 lefse-plot_features.py
mkdir -p F_out
plot_features.py A_lefse_test.in B_lefse_test.res F_out/lefse_test --format pdf --dpi 200

