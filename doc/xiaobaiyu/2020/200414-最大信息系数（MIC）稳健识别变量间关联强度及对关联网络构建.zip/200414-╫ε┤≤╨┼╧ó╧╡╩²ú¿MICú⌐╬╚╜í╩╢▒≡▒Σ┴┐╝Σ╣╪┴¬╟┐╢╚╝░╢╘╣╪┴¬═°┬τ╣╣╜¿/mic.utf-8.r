library(minerva)

#示例数据集，详情 ?Spellman
data(Spellman)
head(Spellman)[1:6]

#我选择其中的一小部分做演示（100 个基因）
#因为后续 MINE 实在是太耗时了......
test <- Spellman[2:101]

#调用 MINE 程序，详情 ?mine
#MINE 的计算比较消耗资源，如果数据量较大需要等待较长时间
#n.cores 参数可以设置多线程运行，加速计算
res <- mine(test, normalization = FALSE, n.cores = 4)

#有很多结果项，这里只关注其中的 MIC 值
#其它类型的统计量，大家有兴趣还请自行了解
names(res)
mic <- res$MIC  #MIC 矩阵
mic[1:6,1:6]

#输出观测值的 MIC 矩阵
#write.table(mic, 'test.mic.txt', sep = '\t', col.names = NA, quote = FALSE)

##可根据置换检验计算 p 值，或通过 bootstrap 估计置信区间
#例如这里随机置换数据 999 次，计算每次置换后数据计算的 MIC（micN），并统计 micN>mic 的频数
n <- 999
p_num <- mic  #如上所述，mic 是观测值的 MIC
p_num[abs(p_num)>0] <- 1

set.seed(123)
for (i in 1:n) {
    random <- apply(test, 2, sample)
    micN <- mine(random, normalization = FALSE, n.cores = 4)$MIC
    
    micN[abs(micN) >= abs(mic)] <- 1
    micN[abs(micN) < abs(mic)] <- 0
    p_num <- p_num + micN
}

#p 值矩阵，即 |micN|>|mic| 的概率
p <- p_num/(n+1)
p[1:6,1:6]

#p 值校正，这里使用 BH 法校正 p 值（p.adjust 文档中提到 BH=FDR）
p <- p.adjust(p, method = 'BH')

#保留校正后 p<0.05 所对应的 MIC 值
mic[p>=0.05] <- 0
mic[1:6,1:6]

#输出 MIC 矩阵，其中 FDR>=0.05 的 MIC 值均已赋值为 0
write.table(mic, 'test.mic.sign.txt', sep = '\t', col.names = NA, quote = FALSE)

##igraph 包的网络处理
library(igraph)

#读取刚刚获得的 MIC 关联矩阵，它同时也是一个网络邻接矩阵
mic <- read.delim('test.mic.sign.txt', row.name = 1, check.names = FALSE)
mic <- as.matrix(mic)

#将邻接矩阵转化为 igraph 网络的邻接列表
#构建含权的无向网络，权重代表了 MIC
g <- graph.adjacency(mic, weighted = TRUE, mode = 'undirected')
g

#去除相关（对角线的值）
g <- simplify(g)

#孤立节点的删除（删除度为 0 的节点）
g <- delete.vertices(g, names(degree(g)[degree(g) == 0]))

#查看网络图（简图......）
plot(g, layout = layout.circle)

##计算 Spearman 秩相关
#直接使用 cor()，这里无需再管 Spearman 秩相关的显著性了
spearman <- cor(test, method = 'spearman')

#设定个阈值吧，0.7 作为有线性关系
#这样，将小于 -0.7 的指定为 -1，大于 0.7 的指定为 1，否则均为 0
spearman[spearman >= 0.7] <- 1
spearman[spearman <= -0.7] <- -1
spearman[!spearman %in% c(-1, 1)] <- 0
diag(spearman) <- 0  #对角线的自相关赋值为 0

#保留其中存在较强 MIC 的关系对（即根据网络中存在的边做取舍）
edge_lise <- as_edgelist(g)
edge <- paste(edge_lise[ ,1], edge_lise[ ,2])

spearman <- reshape2::melt(spearman)
spearman$edge <- paste(spearman$Var1, spearman$Var2)
spearman <- spearman[which(spearman$edge %in% edge), ]
spearman <- spearman[match(edge, spearman$edge), ]

#作图，对于边的颜色，Spearman 正相关为红色，负相关为蓝色，非线性相关为灰色
color <- rep('gray', nrow(spearman))
color[which(spearman$value == 1)] <- 'red'
color[which(spearman$value == -1)] <- 'blue'
E(g)$color <- color

plot(g, layout = layout.circle)

##网络文件导出
#边列表，可以导入至 gephi 或 cytoscape 等网络可视化软件中进行编辑
edge <- data.frame(as_edgelist(g))    #igraph 的邻接列表转为边列表
edge_list <- data.frame(
    source = edge[[1]],
    target = edge[[2]],
    MIC = E(g)$weight,
    spearman = E(g)$color
)
write.table(edge_list, 'network.edge_list.txt', sep = '\t', row.names = FALSE, quote = FALSE)

#此外 igraph 也提供了可以被 gephi 或 cytoscape 等直接识别的格式，例如
#graphml 格式，可使用 gephi 软件打开并进行可视化编辑
write.graph(g, 'network.graphml', format = 'graphml')

#gml 格式，可使用 cytoscape 软件打开并进行可视化编辑
write.graph(g, 'network.gml', format = 'gml')

##MIC 和 Spearman 秩相关的比较
dir.create('plot', recursive = TRUE)
spearman <- cor(test, method = 'spearman')

for (i in 1:(ncol(test)-1)) {
    for (j in (i+1):ncol(test)) {
        name_i <- colnames(test)[i]
        name_j <- colnames(test)[j]
        if (mic[name_i,name_j] > 0) {
            png(paste('plot/', name_i, '-', name_j, '.png', sep = ''), 
                width = 4, height = 4, res = 400, units = 'in', type = 'cairo')
            plot(test[ ,i], test[ ,j], xlab = name_i, ylab = name_j, 
                main = paste('MIC = ', mic[name_i,name_j], '\nSpearman = ', spearman[name_i,name_j]))
            dev.off()
        }
    }
}




