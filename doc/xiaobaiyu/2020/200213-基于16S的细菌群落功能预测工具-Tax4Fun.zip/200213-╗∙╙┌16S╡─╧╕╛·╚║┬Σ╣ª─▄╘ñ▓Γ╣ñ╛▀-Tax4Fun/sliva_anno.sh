##注：以下步骤均在 shell 命令行中完成，运行程序或脚本均来自 qiime
#在 otu_table.tsv 开头添加一行“# Constructed from biom file”，以便将 otu_table.tsv 转为 qiime 可识别样式
cp otu_table.txt otu_table.tsv
sed -i '1i\# Constructed from biom file' otu_table.tsv

#otu_table.tsv 转换为 otu_table.biom
biom convert -i otu_table.tsv -o otu_table.biom --table-type="OTU table" --to-json

#OTU 注释，输出结果 otu_table_tax_assignments.txt 即为注释文件
assign_taxonomy.py -i otu.fasta -r SILVA_123_SSURef_Nr99_tax_silva.fasta -t SILVA_123_SSURef_Nr99_tax_silva.tax -o ./

#添加 otu 注释信息至 biom 格式的 otu 表（otu_table.biom ）的最后一列，并将列名称命名为 taxonomy
biom add-metadata -i otu_table.biom --observation-metadata-fp otu_table_tax_assignments.txt -o otu_table.silva.biom --sc-separated taxonomy --observation-header OTUID,taxonomy 

#otu_table.silva.biom 转换为 otu_table.silva.tsv
biom convert -i otu_table.silva.biom -o otu_table.silva.tsv --to-tsv --header-key taxonomy
