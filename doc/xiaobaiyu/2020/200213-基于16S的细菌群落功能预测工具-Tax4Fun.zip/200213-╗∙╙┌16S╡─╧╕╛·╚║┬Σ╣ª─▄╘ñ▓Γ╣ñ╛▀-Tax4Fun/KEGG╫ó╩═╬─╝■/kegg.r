library(stringr)

argv <- commandArgs(T)
if (argv[1] %in% c(NA, '-h', '--help')) {
	cat('useage:\nRscript kegg.r <kegg.keg> <pathway.result> <gene.result>\nexample:\nRscript kegg.r ko00001.keg pathway.anno.txt gene.anno.txt\n')
	q('no')
}
 
pathway_anno <- file(argv[2], 'w')
gene_anno <- file(argv[3], 'w')
#pathway_anno <- file('pathway.anno.txt', 'w')
#gene_anno <- file('gene.anno.txt', 'w')
cat('KO1_id\tKO1\tKO2_id\tKO2\tKO3_id\tKO3\n', file = pathway_anno)
cat('KO1_id\tKO1\tKO2_id\tKO2\tKO3_id\tKO3\tKO4_id\tKO4\tEC\n', file = gene_anno)

keg <- readLines(argv[1])
#keg <- readLines('ko00001.keg')
for (kegg in keg) {
	if (str_sub(kegg, 1, 1) == 'A' & str_length(kegg) > 1) {
		ko1_id <- str_sub(kegg, 2, 6)
		ko1 <- str_sub(kegg, 8, str_length(kegg))
	}
	if (str_sub(kegg, 1, 1) == 'B' & str_length(kegg) > 1) {
		ko2_id <- str_sub(kegg, 4, 8)
		ko2 <- str_sub(kegg, 10, str_length(kegg))
	}
	if (str_sub(kegg, 1, 1) == 'C' & str_length(kegg) > 1) {
		ko3_id <- str_sub(kegg, 6, 10)
		ko3 <- str_sub(kegg, 12, str_length(kegg))
		if (str_detect(ko3, '\\[')) {
			ko3 <- unlist(str_split(ko3, '\\['))
			ko3 <- str_trim(ko3[1], 'right')
		}
		cat(str_c(str_c(ko1_id, ko1, ko2_id, ko2, ko3_id, ko3, sep = '\t'), '\n'), file = pathway_anno)
	}
	if (str_sub(kegg, 1, 1) == 'D' & str_length(kegg) > 1) {
		ko4_id <- str_sub(kegg, 8, 13)
		ko4_detail <- str_sub(kegg, 16, str_length(kegg))
		if (str_detect(ko4_detail, '\\[')) {
			ko4_detail <- unlist(str_split(ko4_detail, '\\['))
			gene <- str_trim(ko4_detail[1], 'right')
			EC <- str_c('[', ko4_detail[2])
		} else {
			gene <- ko4_detail
			EC <- ''
		}
		cat(str_c(str_c(ko1_id, ko1, ko2_id, ko2, ko3_id, ko3, ko4_id, gene, EC, sep = '\t'), '\n'), file = gene_anno)
	}
}

close(pathway_anno)
close(gene_anno)
