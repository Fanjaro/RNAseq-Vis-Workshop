import sys

if len(sys.argv) == 1 or sys.argv[1] in ['-h', '--help']:
	print('useage:\npython3 kegg.py <kegg.keg> <pathway.result> <gene.result>\nexample:\npython3 kegg.py ko00001.keg pathway.anno.txt gene.anno.txt')
	exit()

pathway_anno = open(sys.argv[2], 'w')
gene_anno = open(sys.argv[3], 'w')
#pathway_anno = open('pathway.anno.txt', 'w')
#gene_anno = open('gene.anno.txt', 'w')
print('KO1_id\tKO1\tKO2_id\tKO2\tKO3_id\tKO3', file = pathway_anno)
print('KO1_id\tKO1\tKO2_id\tKO2\tKO3_id\tKO3\tKO4_id\tKO4\tEC', file = gene_anno)

for kegg in open(sys.argv[1], 'r'):
#for kegg in open('ko00001.keg', 'r'):
	kegg = kegg.strip()
	if kegg[0] == 'A' and len(kegg) > 1:
		ko1_id = kegg[1:6]
		ko1 = kegg[7:len(kegg)]
	elif kegg[0] == 'B' and len(kegg) > 1:
		ko2_id = kegg[3:8]
		ko2 = kegg[9:len(kegg)]
	elif kegg[0] == 'C' and len(kegg) > 1:
		ko3_id = kegg[5:10]
		ko3 = kegg[11:len(kegg)].split(' [')[0]
		print(f'{ko1_id}\t{ko1}\t{ko2_id}\t{ko2}\t{ko3_id}\t{ko3}', file = pathway_anno)
	elif kegg[0] == 'D' and len(kegg) > 1:
		ko4_id = kegg[7:13]
		ko4_detail = kegg[15:len(kegg)]
		if ' [' in ko4_detail:
			ko4_detail = ko4_detail.split(' [')
			gene = ko4_detail[0]
			EC = '[' + ko4_detail[1]
		else:
			gene = ko4_detail
			EC = ''
		print(f'{ko1_id}\t{ko1}\t{ko2_id}\t{ko2}\t{ko3_id}\t{ko3}\t{ko4_id}\t{gene}\t{EC}', file = gene_anno)

pathway_anno.close()
gene_anno.close()
