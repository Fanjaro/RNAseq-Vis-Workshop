library(Tax4Fun)

##Tax4Fun 默认流程
##注：为了结果的准确可靠性，推荐使用 silva 数据库重新注释，尽量不要使用非 silva 数据库的结果
#此处使用“otu_table.silva.tsv”作为输入文件
QIIMESingleData <- importQIIMEData('otu_table.silva.tsv')
folderReferenceData <- 'SILVA123'

#KEGG 功能基因（KO 第四级）丰度预测
Tax4FunOutput <- Tax4Fun(QIIMESingleData, folderReferenceData, fctProfiling = TRUE, refProfile = 'UProC', shortReadMode = TRUE, normCopyNo = TRUE)
tax4fun_gene <- as.data.frame(t(Tax4FunOutput$Tax4FunProfile))
gene <- rownames(tax4fun_gene)
write.table(cbind(gene, tax4fun_gene), 'tax4fun.gene.txt', row.names = FALSE, sep = '\t', quote = FALSE)

#KEGG 代谢通路（KO 第三级）丰度预测
Tax4FunOutput <- Tax4Fun(QIIMESingleData, folderReferenceData, fctProfiling = FALSE, refProfile = 'UProC', shortReadMode = TRUE, normCopyNo = TRUE)
tax4fun_pathway <- as.data.frame(t(Tax4FunOutput$Tax4FunProfile))
pathway <- rownames(tax4fun_pathway)
write.table(cbind(pathway, tax4fun_pathway), 'tax4fun.pathway.txt', row.names = FALSE, sep = '\t', quote = FALSE)

##为 KEGG 代谢通路映射 KO 分类
#“pathway.anno.txt”为已经整理好的 KEGG 注释文件（可见网盘附件）
kegg_anno <- read.delim('pathway.anno.txt', sep = '\t', colClasses = 'character', check.names = FALSE)
tax4fun_pathway$KO3_id <- t(data.frame(strsplit(rownames(tax4fun_pathway), ';')))[ ,1]
tax4fun_pathway$KO3_id <- gsub('ko', '', tax4fun_pathway$KO3_id)
tax4fun_pathway <- merge(tax4fun_pathway, kegg_anno, by = 'KO3_id')
write.table(tax4fun_pathway, 'tax4fun.pathway.anno.txt', row.names = FALSE, sep = '\t', quote = FALSE)

##添加样本分组信息，统计检验，并作图展示
#在KO 第二级统计求和，并添加样本分组信息
group <- read.delim('group.txt', sep = '\t', stringsAsFactors = FALSE, check.names = FALSE)
names(group)[1] <- 'variable'
tax4fun_pathway <- tax4fun_pathway[c(group$variable, 'KO2_id')]
tax4fun_pathway <- reshape2::melt(tax4fun_pathway, id = 'KO2_id')
tax4fun_pathway <- doBy::summaryBy(value~variable+KO2_id, tax4fun_pathway, FUN = sum)
tax4fun_pathway <- merge(tax4fun_pathway, group, by = 'variable')

#计算均值（mean）±标准差（sd），或标准误差（se）
se <- function(x) sd(x) / (length(x))^0.5
pathway_stat <- doBy::summaryBy(value.sum~group+KO2_id, tax4fun_pathway, FUN = c(mean, sd, se))

#添加注释
kegg_anno_2 <- kegg_anno[!duplicated(kegg_anno$KO2), ][-c(5:7)]
pathway_stat <- merge(pathway_stat, kegg_anno_2, by = 'KO2_id', all.x = TRUE)
#write.table(pathway_stat, 'tax4fun.KO2.anno.txt', row.names = FALSE, sep = '\t', quote = FALSE)

#显著性差异分析，例如这里直接使用非参数的 wilcoxon 检验两组间差异
KO2_id <- unique(tax4fun_pathway$KO2_id)
for (i in KO2_id) {
	tax4fun_pathway_2_i <- subset(tax4fun_pathway, KO2_id == i)
	test <- wilcox.test(value.sum~group, tax4fun_pathway_2_i)
	line_t <- which(pathway_stat$KO2_id == i & pathway_stat$group == 'treat')
	pathway_stat[line_t,'p_value'] <- test$p.value
	if (test$p.value < 0.05 & test$p.value >= 0.01) {
		pathway_stat[line_t,'sign'] <- '*'
	}
	if (test$p.value < 0.01 & test$p.value >= 0.001) {
		pathway_stat[line_t,'sign'] <- '**'
	}
	if (test$p.value < 0.001) {
		pathway_stat[line_t,'sign'] <- '***'
	}
}

#write.table(pathway_stat, 'tax4fun.KO2.anno_stat.txt', row.names = FALSE, sep = '\t', quote = FALSE, na = '')

##使用 ggplot2 作图
library(ggplot2)

#给 KO 名称按丰度数值大小排个序
pathway_stat <- pathway_stat[order(pathway_stat$value.sum.mean), ]
pathway_stat$KO2 <- factor(pathway_stat$KO2, levels = unique(pathway_stat$KO2))
pathway_stat$KO1 <- factor(pathway_stat$KO1, levels = rev(unique(pathway_stat$KO1)))

#作图
pathway_stat$value.sum.mean <- 100 * pathway_stat$value.sum.mean
pathway_stat$value.sum.sd <- 100 * pathway_stat$value.sum.sd

ko2_plot <- ggplot(pathway_stat, aes(x = KO2, y = value.sum.mean, fill = group)) +
geom_col(position = 'dodge', width = 0.8, colour = 'black', size = 0.05) +  #“dodge 柱状图”样式
scale_fill_manual(values = c('red', 'blue')) +  #填充颜色
geom_errorbar(aes(ymin = value.sum.mean - value.sum.sd, ymax = value.sum.mean + value.sum.sd), 
    size = 0.05, width = 0.35, position = position_dodge(width = 0.8)) +  #添加误差线（均值±标准差）
geom_text(aes(label = sign, y = value.sum.mean + value.sum.sd + 0.5), size = 4, position = position_dodge(0.8)) +  #添加显著性标记“*”
facet_grid(KO1~., space = 'free', scale = 'free_y') + #分面图，按 KO1 分类
coord_flip() +  #横、纵坐标轴反转
theme(panel.grid = element_blank(), panel.background = element_rect(fill = 'transparent',  color = 'black'), 
    legend.title = element_blank(), legend.position = 'top') +  #背景、图例主题等设置
labs(x = 'KEGG Orthology (KO)', y = 'Relative Abundance (%)')  #坐标轴标题

ggsave('ko2_stat.pdf', ko2_plot, width = 8, height = 10)
ggsave('ko2_stat.png', ko2_plot, width = 8, height = 10)
