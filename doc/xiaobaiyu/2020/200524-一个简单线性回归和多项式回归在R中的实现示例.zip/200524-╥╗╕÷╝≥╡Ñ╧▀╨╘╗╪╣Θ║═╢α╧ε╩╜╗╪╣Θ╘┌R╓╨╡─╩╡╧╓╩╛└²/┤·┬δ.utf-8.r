# 测试数据的来源
# https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4845060/

####数据预处理
##根据经纬度计算采样点的地理距离
#读取采样点的地理位置数据
site <- read.delim('site.txt', sep = '\t', row.names = 1, check.names = FALSE)
#site <- site[which(site$'Lat (°N)' > 0), ]  #只选择北半球
#site <- site[which(site$'Lat (°N)' < 0), ]  #只选择南半球

#计算采样点间的地理距离
#geosphere 包 distm() 根据经纬度计算地理距离（默认距离单位，米）
#distm() 要求两列数据，第一列是经度，第二列是纬度
site_dis <- geosphere::distm(site[c('Lon (°E)', 'Lat (°N)')]) 
rownames(site_dis) <- rownames(site)
colnames(site_dis) <- rownames(site)

#将采样点地理距离矩阵转换为两两对应数值的数据框结构
site_dis <- reshape2::melt(site_dis)
site_dis <- subset(site_dis, value != 0)
head(site_dis)

##计算群落间物种组成相似度，根据原文描述，使用 Bray-curtis 相似度
#浮游细菌群落物种组成数据
spe <- read.delim('FL.depth40.otu_table.txt', sep = '\t', row.names = 1, check.names = FALSE)
spe <- data.frame(t(spe))
spe <- spe[rownames(site), ]  #与 site 中预先选择的南北半球数据对应

#vegan 包 vegdist() 计算群落间物种组成 Bray-curtis 相异度矩阵
#并通过 1-Bray-curtis 相异度获得 Bray-curtis 相似度
comm_sim <- 1 - as.matrix(vegan::vegdist(spe, method = 'bray'))

#将矩阵转换为两两群落对应数值的数据框结构
diag(comm_sim) <- 0  #去除群落相似度矩阵中的对角线值，它们是样本的自相似度
comm_sim[upper.tri(comm_sim)] <- 0  #群落相似度矩阵是对称的，因此只选择半三角（如下三角）区域的数值即可
comm_sim <- reshape2::melt(comm_sim)
comm_sim <- subset(comm_sim, value != 0)
head(comm_sim)

##采样点距离和群落相似度数据合并
comm_dis <- merge(comm_sim, site_dis, by = c('Var1', 'Var2'))
names(comm_dis) <- c('site1', 'site2', 'comm_sim', 'site_dis')

#标识与最北 NADR 或最南 FKLD 地区中采样地点有关的距离对
site_edge <- rownames(subset(site, Province %in% c('NADR', 'FKLD')))
comm_dis[which(as.character(comm_dis$site1) %in% site_edge | as.character(comm_dis$site2) %in% site_edge),'edge'] <- '0'
comm_dis[which(! comm_dis$edge %in% '0'),'edge'] <- '1'
head(comm_dis)

write.table(comm_dis, 'comm_dis.depth40.Both.txt', sep = '\t', row.names = FALSE, quote = FALSE)
#write.table(comm_dis, 'comm_dis.depth40.North.txt', sep = '\t', row.names = FALSE, quote = FALSE)
#write.table(comm_dis, 'comm_dis.depth40.South.txt', sep = '\t', row.names = FALSE, quote = FALSE)

####一元一次回归
##首先是北半球的
#读取上述输出文件，首先以北半球的为例
comm_dis <- read.delim('comm_dis.depth40.North.txt', sep = '\t')

#注：site_dis 列的单位是米（m），在这种大尺度范围下，以千米（km）作为度量会更好一些
comm_dis$site_dis_km <- comm_dis$site_dis/1000

#lm() 拟合群落组成相似度（comm_sim）地理距离（site_dis_km）的一元线性关系
fit <- lm(comm_sim~site_dis_km, data = comm_dis)
summary(fit)  #展示拟合模型的简单统计

#提取重要数值，例如
coefficients(fit)[1]  #获取截距
coefficients(fit)[2]  #获取 site_dis_km 的斜率

#也可以 names(summary(fit)) 后查看主要的内容项，然后从中提取，例如
summary(fit)$adj.r.squared  #校正后 R2

##ggplot2 绘制带线性拟合线的散点图
#拟合线同时考虑了“黑点”和“红点”，其中“红点”代表了与 NADR 地区中采样地点有关的距离关系
library(ggplot2)

p <- ggplot(comm_dis, aes(site_dis_km, comm_sim)) +
geom_point(aes(color = as.character(edge))) +
scale_color_manual(values = c('red', 'black'), limit = c('0', '1')) +
geom_smooth(method = 'lm', se = FALSE) +
theme(panel.grid = element_blank(), panel.background = element_rect(color = 'black', fill = 'transparent'), 
    legend.position = 'none', plot.title = element_text(hjust = 0.5)) +
scale_y_continuous(limit = c(0, 1)) +
labs(x = 'Distance (km)', y = 'Bray-curtis similarity', title = 'North')

#提取上述结果中重要的统计值，用于在图中将方程式标注出
label_fit <- data.frame(
    formula = sprintf('italic(Y) == %.7f*italic(X) + %.3f', coefficients(fit)[2], coefficients(fit)[1]),
    R2 = sprintf('italic(R^2) == %.3f', summary(fit)$adj.r.squared),
    p_value = sprintf('italic(P) < %.3f', 0.001))

p +
geom_text(x = 3000, y = 0.9, aes(label = formula), data = label_fit, parse = TRUE, 
    hjust = 0, color = 'black', show.legend = FALSE) +
geom_text(x = 4000, y = 0.8, aes(label = R2), data = label_fit, parse = TRUE, 
    hjust = 0, color = 'black', show.legend = FALSE) +
geom_text(x = 4000, y = 0.7, aes(label = p_value), data = label_fit, parse = TRUE, 
    hjust = 0, color = 'black', show.legend = FALSE)

##其次是南半球的
#读取上述输出文件，南半球的样点距离与群落相似度数据
comm_dis <- read.delim('comm_dis.depth40.South.txt', sep = '\t')

#注：site_dis 列的单位是米（m），在这种大尺度范围下，以千米（km）作为度量会更好一些
comm_dis$site_dis_km <- comm_dis$site_dis/1000

#lm() 拟合群落组成相似度（comm_sim）地理距离（site_dis_km）的一元线性关系
#拟合时不再考虑与 FKLD 地区中采样地点有关的距离关系
comm_dis_select <- subset(comm_dis, edge == '1')

fit <- lm(comm_sim~site_dis_km, data = comm_dis_select)
summary(fit)  #展示拟合模型的简单统计

##ggplot2 绘制带线性拟合线的散点图
#拟合线只考虑“黑点”，“红点”代表了与 FKLD 地区中采样地点有关的距离关系，因偏离太大被剔除
library(ggplot2)

p <- ggplot() +
geom_point(data = comm_dis, aes(x = site_dis_km, y = comm_sim, color = as.character(edge))) +
scale_color_manual(values = c('red', 'black'), limit = c('0', '1')) +
geom_smooth(data = comm_dis_select, aes(x = site_dis_km, y = comm_sim), method = 'lm', se = FALSE) +
theme(panel.grid = element_blank(), panel.background = element_rect(color = 'black', fill = 'transparent'), 
    legend.position = 'none', plot.title = element_text(hjust = 0.5)) +
scale_y_continuous(limit = c(0, 1)) +
labs(x = 'Distance (km)', y = 'Bray-curtis similarity', title = 'South')

#提取上述结果中重要的统计值，用于在图中将方程式标注出
label_fit <- data.frame(
    formula = sprintf('italic(Y) == %.6f*italic(X) + %.3f', coefficients(fit)[2], coefficients(fit)[1]),
    R2 = sprintf('italic(R^2) == %.3f', summary(fit)$adj.r.squared),
    p_value = sprintf('italic(P) < %.3f', 0.001))

p +
geom_text(x = 4000, y = 0.9, aes(label = formula), data = label_fit, parse = TRUE, 
    hjust = 0, color = 'black', show.legend = FALSE) +
geom_text(x = 5000, y = 0.8, aes(label = R2), data = label_fit, parse = TRUE, 
    hjust = 0, color = 'black', show.legend = FALSE) +
geom_text(x = 5000, y = 0.7, aes(label = p_value), data = label_fit, parse = TRUE, 
    hjust = 0, color = 'black', show.legend = FALSE)

##多项式回归
#读取上述输出文件，综合考虑南北半球大西洋的样点距离与群落相似度数据
comm_dis <- read.delim('comm_dis.depth40.Both.txt', sep = '\t')

#注：site_dis 列的单位是米（m），在这种大尺度范围下，以千米（km）作为度量会更好一些
comm_dis$site_dis_km <- comm_dis$site_dis/1000

#lm() 拟合群落组成相似度（comm_sim）地理距离（site_dis_km）的线性关系
#首先不妨先看一下简单一次线性回归的结果
fit1 <- lm(comm_sim~site_dis_km, data = comm_dis)
summary(fit1)  #展示拟合模型的简单统计，发现 R2 是很低的

#然后上述简单线性回归基础上添加个二次项
#I(X^2) 添加二次项，I(X^3) 可添加三次项，以此类推
fit2 <- lm(comm_sim~site_dis_km+I(site_dis_km^2), data = comm_dis)
summary(fit2)  #展示拟合模型的简单统计，相比一次线性回归有效提高了回归精度

##ggplot2 绘制带线性拟合线的散点图
library(ggplot2)

p <- ggplot(comm_dis, aes(x = site_dis_km, y = comm_sim)) +
geom_point(color = 'black') +
geom_smooth(method = 'lm', se = FALSE, color = 'blue', formula = y~x) +
geom_smooth(method = 'lm', se = FALSE, color = 'blue4', formula = y~poly(x, 2)) +
theme(panel.grid = element_blank(), panel.background = element_rect(color = 'black', fill = 'transparent'), 
    legend.position = 'none', plot.title = element_text(hjust = 0.5)) +
scale_y_continuous(limit = c(0, 1)) +
labs(x = 'Distance (km)', y = 'Bray-curtis similarity', title = 'Both')

#这次就不标出具体的拟合式了，只标出简单一次和二次回归的 R2 比较
label_fit <- data.frame(
    R1_2 = sprintf('italic(R^2) == %.3f', summary(fit1)$adj.r.squared),
    R2_2 = sprintf('italic(R^2) == %.3f', summary(fit2)$adj.r.squared))

p +
geom_text(x = 10000, y = 0.9, aes(label = R1_2), data = label_fit, parse = TRUE, 
    hjust = 0, color = 'blue', show.legend = FALSE) +
geom_text(x = 10000, y = 0.8, aes(label = R2_2), data = label_fit, parse = TRUE, 
    hjust = 0, color = 'blue4', show.legend = FALSE)
